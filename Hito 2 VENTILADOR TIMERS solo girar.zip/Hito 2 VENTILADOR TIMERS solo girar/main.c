#include <LPC17xx.h>
#include "reg_masks.h"

#define F_CPU       (SystemCoreClock)		//Frecuencia de la CPU = 100MHz
#define F_PCLK      (F_CPU/4)						//PCLK = CCLK/4 = 25MHz

//Para el VENTILADOR: (4 hilos)
//f = 25[kHz] -> T = 40[us]	(PDF habla de entre 21 y 28 [kHz])
#define F_PWM_VENTILADOR 			25000

//Para nuestro PCLK = 25[MHz] y f = 25 [kHz] --> 25[MHz]/25[kHz] = 1000 ticks del Timer (Niveles Duty Cycle)
#define TICKS 			(F_PCLK/F_PWM_VENTILADOR)

volatile uint32_t duty = 50; 								//Cambiando esto variamos el Ciclo de Trabajo (rendimiento) del Ventilador (0, 100)%

void set_duty_ventilador(uint8_t d);        //La funci�n est� definida m�s abajo, pero como est� dentro del
																						//void ventilador_init(void) es necesario "definirla" o decirle que existe antes

//Configuraci�n de RELOJ + PINES
void ventilador_init(void)
{
	LPC_SC->PCONP |= (1 << 23);							//Alimentamos Timer3 ya que despu�s del RESET est� apagado (Bit 23 es el que corresponde al Timer3)
	
	LPC_PINCON->PINSEL0 &= ~(3 << 20);		  //El pin P0.10 usa los bits 2n+1:2n de PINSEL0 para limpiar bits 21:20
	LPC_PINCON->PINSEL0 |= (3 << 20);				//Ahora ponemos 11 en MAT3.0
	
	LPC_TIM3->TCR = (1 << 1); 							//Paramos y con TCR reseteamos el contador
	LPC_TIM3->PR = 0;
	LPC_TIM3->MR0 = TICKS - 1;
	LPC_TIM3->MCR = (1 << 1);								//MR0: reset del contador//MCR: va a resetear TC al coincidir con MR0
	LPC_TIM3->EMR = (2 << 4);								//EMC0 = 10: poner MAT3.0 a 1 al coincidir MR0
	LPC_TIM3->IR = 0x3F;
	
	NVIC_EnableIRQ(TIMER3_IRQn);            //Habilita la interrupci�n del TIMER3 en el NVIC (sin esto la ISR nunca saltar�a)
	
	set_duty_ventilador(0);                 //Empezamos con el ventilador parado
  LPC_TIM3->TCR = (1 << 0);        				//Con TCR habilitamos el contador y arrancamos el timer
}

//De teor�a sabemos:
//Periodo: T_PWM = T_PCLK � (PR + 1) � (MRx + 1)
//Tiempo en HIGH: t_H = T_PCLK � (PR + 1) � (MRy + 1)
//DUTY: d = t_H / T_PWM --> Despejando nos queda: d = (MRy + 1) / (MRx + 1)
//Ponemos "+1" porque el contador empieza en 0 --> Nosotros definimos 1000 ticks y MR0 cuenta desde 0 hasta 999 (1000 valores), pero no llega a 1000
//MRx = MR0 (portadora)
//MRy = MR1 (punto de OFF)

//CONCLUSI�N:
//d = (MRy + 1) / (MRx + 1)					y 				MR1 = d * (MR0 + 1) - 1
//"d" es un porcentaje   -->   MR1 = d * ((MR0+1)/100) - 1

//Ahora vamos a fijar la velocidad del ventilador a partir del Ciclo de Trabajo que le metamos
//d = 0 - 100%
//Calculamos el MR1 del Timer3
void set_duty_ventilador(uint8_t d)
{
	if (d > 100) //No podemos pasarnos de 100
  {
		d = 100; //Lo vamos a fijar a 100 que es lo m�ximo que aceptamos
  }

	//PODEMOS TENER HASTA 3 CASOS DE FUNCIONAMIENTO:

	//d = 0% -> pin fijo a 0 (VENTILADOR PARADO)
	//d == 0: quita la interrupci�n de MR1, quita la acci�n autom�tica de MR0 y fuerza el pin a 0. El pin queda apagado siempre y no se activa nada.
  if (d == 0)
  {
		//x &= ~(bit) --> apaga ese bit.
		LPC_TIM3->MCR &= ~(1 << 3);											//MCR: interrumpe cuando el contador llegue a MR1
    LPC_TIM3->EMR &= ~((3 << 4) | (1 << 0));				//EMR: acci�n de MAT3.0 al coincidir MR0
																										//EMR: indica el estado del pin MAT3.0 (1 = ON) (0 = OFF)
  }

	//d = 100% -> pin fijo a 1 (M�XIMA VELOCIDAD)
	//d == 100: igual, pero fuerza el pin a 1 (EMR = ... | (1 << 0)). Queda encendido siempre.
	else if (d == 100)					
  {
		LPC_TIM3->MCR &= ~(1 << 3);																			//MCR: interrumpe cuando el contador llegue a MR1
    LPC_TIM3->EMR  = (LPC_TIM3->EMR & ~(3 << 4)) | (1 << 0);				//EMR: acci�n de MAT3.0 al coincidir MR0
																																		//EMR: indica el estado del pin MAT3.0 (1 = ON) (0 = OFF)
  }
		
	//Caso PWM normal: HW activa en MR0, SW desactiva en MR1
	//Normal: calcula MR1 con la f�rmula, activa la acci�n de MR0 que enciende el pin por hardware (2 << 4) y activa la interrupci�n de MR1 (MCR |= 1 << 3).
  else
  {
		LPC_TIM3->MR1  = (d * (LPC_TIM3->MR0 + 1)) / 100 - 1;
    LPC_TIM3->EMR  = (LPC_TIM3->EMR & ~(3 << 4)) | (2 << 4);				//EMR: acci�n de MAT3.0 al coincidir MR0//EMC0 = 10: poner MAT3.0 a 1 al coincidir MR0
																																		//--> primero borra los dos bits del campo y despu�s escribe el valor nuevo, sin tocar el resto del registro.
		//x |= bit --> lo enciende.
		LPC_TIM3->MCR |= (1 << 3);
  }
}

//Cuando el contador del TIMER3 alcanza el valor de MR1, el programa salta a esta sentencia
void TIMER3_IRQHandler(void)
{
	if (LPC_TIM3->IR & (1 << 1))			//comprobamos que el bit 1 es el del MR1 que ha saltado
	{
		LPC_TIM3->IR = (1 << 1);       	//Primero borramos el aviso escribiendo un '1' ("=" es una asignaci�n directa)
																	  //Si pusiesemos "|=" no borrar�amos registro, el programa pensar�a que la interrupci�n
																		//sigue pendiente y saltar�a sin parar, el programa no avanzar�a
    LPC_TIM3->EMR &= ~(1 << 0);     //MAT3.0 -> Lo ponemos a '0' y se apaga el pin (EMR indica el estado del pin MAT3.0)
  }
}

//AMPLIACI�N:
//duty = 100% -> LED rojo -> PIN (P0.0) N�dePin = 46
//duty = 50 - 99% -> LED amarillo -> PIN (P0.1) N�dePin = 47
//duty = 1 - 49% -> LED verde -> PIN (P0.11) N�dePin = 49 (VENTILADOR est� en el P0.10)
//duty = 0%  -> LEDS apagados (no est� ON)

//Determinamos PINES de los LEDS
void leds_init(void)
{
  //Los 3 pines como GPIO (00):
	//bits 1:0 -> P0.0
	//bits 3:2 -> P0.1
	//bits 23:22 -> P0.11
  //No tocamos los bits 21:20 (P0.10 = MAT3.0 del ventilador)
  
	LPC_PINCON->PINSEL0 &= ~((3 << 0) | (3 << 2) | (3 << 22));

	LPC_GPIO0->FIODIR |= ((1 << 0) | (1 << 1) | (1 << 11));     //Asignamos las salidas
	LPC_GPIO0->FIOCLR  = ((1 << 0) | (1 << 1) | (1 << 11));     //Inicio = todo apagado
}

//Asignamos la funci�n que debe cumplir el LED seg�n lo que pase
void actualizar_leds(uint8_t d)
{
	//Al inicio queremos todo apagado asi que lo asignamos com '0' (ning�n LED ON)
	uint32_t encender = 0;

	if      (d == 100) encender = (1 << 0);    		//100%
	else if (d >= 50)  encender = (1 << 1);   		//50% - 99%
	else if (d >= 1)   encender = (1 << 11);      //1% - 49%

	LPC_GPIO0->FIOCLR = ((1 << 0) | (1 << 1) | (1 << 11)) & ~encender;      //Apagamos los que est�n OFF '0'
	LPC_GPIO0->FIOSET = encender;     //Enciende el que est� ON '1'
}

//BUCLE PRINCIPAL
int main(void)
{
	uint8_t anterior = 255;           //Aqu� guardamos el �ltimo valor del DUTY
																		//La iniciamos a 255 porque DUTY solo puede valer [0, 100]
																		//255 es un valor imposible, as� que pase lo que pase en el bucle de abajo
																		//duty != anterior siempre se cumple y se aplica el valor inicial de arriba (50)

	SystemCoreClockUpdate();
	ventilador_init(); 								//Prepara la llamada a la configuraci�n del RELOJ y los PINES que hemos hecho arriba
	leds_init();											//Prepara la llamada a la configuraci�n de LEDS y los PINES que hemos hecho arriba
	
	while (1)
  {
		if (duty != anterior)           //Analiza si ha cambiado el valor para actualizarlo
		{
			set_duty_ventilador(duty);		//Realiza el cambio con el c�digo de arriba respecto al DUTY nuevo
			actualizar_leds(duty);				//Manda el numero duty a la funci�n donde determinamos que color de LED se enciende
      anterior = duty;							//Guardamos el valor para, en el futuro, hacer un cambio otra vez
    }
  }
}